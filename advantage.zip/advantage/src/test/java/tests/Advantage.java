package tests;

import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.Keys;


public class Advantage {

	// DADO que estou na p�gina inicial do site https://advantageonlineshopping.com
	public void assertUrl(WebDriver driver) throws InterruptedException {
		Assert.assertEquals(driver.getCurrentUrl(), "https://advantageonlineshopping.com/#/");
		Thread.sleep(3000);
	}

	// QUANDO clico na op��o "Special Offer" no menu
	public void specialOfferButton(WebDriver driver) throws InterruptedException {
		WebElement specialOfferButton = driver.findElement(By.xpath("/html/body/header/nav/ul/li[7]/a"));
		specialOfferButton.click();
		Thread.sleep(5000);
	}

	// E clico no bot�o "See offer"
	public void seeOfferButton(WebDriver driver) throws InterruptedException {
		WebElement seeOfferButton = driver.findElement(By.xpath("//button[@id='see_offer_btn']"));
		seeOfferButton.click();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollTo(0,0);");
		Thread.sleep(5000);
	}

//	//E altero a cor do produto para a cor informada no banco de automa��o
//	public void dbButtonCollor(WebDriver driver) throws InterruptedException {
//		String queryCollor = 
//        WebElement dbButtonCollor = Query    SELECT COLOR FROM massas
//        specialOfferButton.click();
//        Thread.sleep(5000);
//	}

	// E clico no bot�o "Add to cart"
	public void addToCartButton(WebDriver driver) throws InterruptedException {
		WebElement addToCartButton = driver.findElement(By.id("productProperties"));
		addToCartButton.click();
		Thread.sleep(5000);
	}

	// QUANDO clico na op��o "Search" e digito o nome do produto do banco de
	// automa��o
	public void searchInput(WebDriver driver) throws InterruptedException {
		WebElement searchInput = driver.findElement(By.id("menuSearch"));
		searchInput.click();
		Thread.sleep(2000);
		WebElement campoSearch = driver.findElement(By.id("autoComplete"));
		campoSearch.sendKeys("autoComplete");
		Thread.sleep(2000);
	}

	// E clico no �cone de busca
	public void searchIn(WebDriver driver) throws InterruptedException {
		WebElement searchInput = driver.findElement(By.id("menuSearch"));
		searchInput.click();
		Thread.sleep(2000);
		WebElement viewAllButton = driver.findElement(By.xpath("//a[contains(text(),'View All')]"));
		viewAllButton.click();
		Thread.sleep(2000);
		WebElement quitSearch = driver.findElement(By.xpath("//div[@id='search']/div/div/img"));
		quitSearch.click();
		Thread.sleep(2000);
	}

	// E seleciono o produto pesquisado
	public void selectProduct(WebDriver driver) throws InterruptedException {
		WebElement searchInput = driver
				.findElement(By.xpath("//article[@id='searchPage']/div[3]/div/div/div[2]/ul/li/img"));
		searchInput.click();
		Thread.sleep(2000);
	}

	// E altero a cor do produto para uma diferente da existente no banco de
	// automa��o
	public void otherCollor(WebDriver driver) throws InterruptedException {
		Thread.sleep(2000);
		WebElement otherCollor = driver
				.findElement(By.xpath("//article[@id='searchPage']/div[3]/div/div/div[2]/ul/li/img"));
		otherCollor.click();
	}

	// E altero a quantidade de produtos que desejo comprar
	public void altQtdProduct(WebDriver driver) throws InterruptedException {
		WebElement inputAltQtdProduct = driver.findElement(By.id("ENTRADA_QTD_PRODUTOS"));
		inputAltQtdProduct.sendKeys(Keys.chord(Keys.CONTROL, "a"), "5");
		Thread.sleep(2000);
	}

	// E altero a cor do produto para uma diferente da existente no banco de
	// automa��o
	public void setDiffCollor(WebDriver driver) throws InterruptedException {
		WebElement setDiffCollor = driver.findElement(By.id("@id=\"bunny\""));
		setDiffCollor.click();
		Thread.sleep(2000);
	}

	public void addProduct(WebDriver driver) throws InterruptedException {
		WebElement addProduct = driver.findElement(By.cssSelector("#menuCart"));
		addProduct.click();
		Thread.sleep(2000);
	}

	// ENT�O o carrinho de compras deve estar vazio
	public void msgEmptyCar(WebDriver driver) throws InterruptedException {
		Thread.sleep(2000);
		WebElement msgEmptyCar = driver.findElement(By.xpath("//*[@id='shoppingCart']/div/label"));

		if (msgEmptyCar.getText().contains("Your shopping cart is empty")) {
			System.out.println(true);
		} else {
			System.out.println(false);
		}
		Thread.sleep(2000);
	}

	// E clico no �cone do carrinho de compras
	public void shopCar(WebDriver driver) throws InterruptedException {
		WebElement shopCar = driver.findElement(By.cssSelector("#menuCart"));
		shopCar.click();
		Thread.sleep(2000);
	}
	
	// E removo o produto do carrinho
	public void shopRemove(WebDriver driver) throws InterruptedException {
		WebElement shopRemove = driver.findElement(By.xpath("//tr[@id='product']/td[3]/div/div"));
		shopRemove.click();
		Thread.sleep(2000);
	}
			
	@Test
	public void test1() throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://advantageonlineshopping.com");
		driver.manage().window().maximize();
		Thread.sleep(3000);
		// DADO que estou na p�gina inicial do site https://advantageonlineshopping.com
		assertUrl(driver);
		// QUANDO clico na op��o "Special Offer" no menu
		specialOfferButton(driver);
		// E clico no bot�o "See offer"
		seeOfferButton(driver);
		// ENT�O as especifica��es do produto s�o exibidas corretamente de acordo com as
		// informa��es retornadas do banco de automa��o

		driver.quit();
	}

	@Test
	public void test2() throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://advantageonlineshopping.com");
		driver.manage().window().maximize();
		Thread.sleep(3000);
		// DADO que estou na p�gina inicial do site https://advantageonlineshopping.com
		assertUrl(driver);
		// QUANDO clico na op��o "Special Offer" no menu
		specialOfferButton(driver);
		// E clico no bot�o "See offer"
		seeOfferButton(driver);
		// E altero a cor do produto para uma diferente da existente no banco de
		// automa��o
		setDiffCollor(driver);
		// E clico no bot�o "Add to cart"
		addToCartButton(driver);
		// ENT�O o produto � adicionado ao carrinho com a cor selecionada.
		addProduct(driver);
		driver.quit();
	}

	@Test
	public void test3() throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://advantageonlineshopping.com");
		driver.manage().window().maximize();
		Thread.sleep(3000);
		// DADO que estou na p�gina inicial do site https://advantageonlineshopping.com
		assertUrl(driver);
		// QUANDO clico na op��o "Search" e digito o nome do produto do banco de
		// automa��o
		// E clico no �cone de busca
		// E seleciono o produto pesquisado
		// E altero a cor do produto para uma diferente da existente no banco de
		// automa��o
		// E altero a quantidade de produtos que desejo comprar
		// E clico no bot�o "Add to cart"
		addToCartButton(driver);
		// E acesso a p�gina de checkout
		// ENT�O valido que a soma dos pre�os corresponde ao total apresentado na p�gina
		// de checkout
		// E realizo um update no banco de automa��o alterando a cor existente no banco
		// para a cor selecionada no teste

		driver.quit();
	}

	@Test
	public void test4() throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://advantageonlineshopping.com");
		driver.manage().window().maximize();
		Thread.sleep(3000);
		// DADO que estou na p�gina inicial do site https://advantageonlineshopping.com
		assertUrl(driver);
		// QUANDO clico na op��o "Special Offer" no menu
		specialOfferButton(driver);
		// E clico no bot�o "See offer"
		seeOfferButton(driver);
		// E clico no bot�o "Add to cart"
		addToCartButton(driver);
		// E clico no �cone do carrinho de compras
		shopCar(driver);
		// E removo o produto do carrinho
	    shopRemove(driver);
		// ENT�O o carrinho de compras deve estar vazio
		msgEmptyCar(driver);
		driver.quit();
	}
}
